# -*- coding: utf-8 -*-

__author__ = "MarcosScholl"
__date__ = "$10/06/2015 17:19:40$"

from .alarm import Alarm
__all__=['Alarm']